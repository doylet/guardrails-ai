# ADR N: Title
- Date: YYYY-MM-DD
- Status: Proposed | Accepted | Superseded by ADR M
## Context
What problem are we solving? Constraints?
## Decision
What is decided? Why this over alternatives?
## Consequences
Risks, migrations, sunsets, and how we'll measure success.
