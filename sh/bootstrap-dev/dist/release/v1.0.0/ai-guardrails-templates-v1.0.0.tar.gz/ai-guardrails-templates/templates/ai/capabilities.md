---
description: [Capture an overview of project capabilities to keep copilot on guardrails.]
---

# Capabilities Registry

## Title
- Purpose:
- Entry points:
- CLI:
- Contracts:
- Tests:
- Notes: Do **not** re-implement; extend via layouts or themes only.
(Add more capability stubs and keep this current.)
